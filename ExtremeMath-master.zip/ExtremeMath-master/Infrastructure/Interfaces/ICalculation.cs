﻿namespace Infrastructure.Interfaces
{
    public interface ICalculation
    {
        object Add(object number1, object number2);
        object Subtract(object number1, object number2);
    }
}
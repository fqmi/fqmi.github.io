﻿"use strict";
define([currentApp], function (app) {
    app.register.controller(Constants.ControllerNames.Footer,
        ['$scope', function ($scope) {

            var init = function () {

            };
            init();
        }]);
});
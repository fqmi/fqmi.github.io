﻿"use strict";
define([currentApp], function (app) {
    app.register.controller(Constants.ControllerNames.NavBar,
        ['$scope', function ($scope) {

            var init = function () {

            };
            init();
        }]);
});
﻿"use strict";
define([currentApp], function (app) {
    app.register.controller(Constants.ControllerNames.SideBar,
        ['$scope', function ($scope) {

            var init = function () {

            };
            init();
        }]);
});
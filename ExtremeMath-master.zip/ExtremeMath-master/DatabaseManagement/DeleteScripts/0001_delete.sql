delete from tbl_user where id = 0 
select N'Delete script executed' 
GO 
use $(db_name); 
create fulltext catalog nepromasys_fulltext_catalog with accent_sensitivity = off as default; 